from django.contrib import admin
from .models import Concept

admin.site.register(Concept)
