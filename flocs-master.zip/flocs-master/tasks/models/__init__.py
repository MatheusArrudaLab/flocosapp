"""Persistence layer (data model) of tasks app
"""
from .task import TaskModel
