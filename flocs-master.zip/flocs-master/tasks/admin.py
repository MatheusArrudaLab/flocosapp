from django.contrib import admin
from .models.task import TaskModel

# Register your models here.
admin.site.register(TaskModel)
