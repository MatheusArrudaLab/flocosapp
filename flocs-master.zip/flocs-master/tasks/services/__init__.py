"""Service layer (domain model) of tasks app
"""

