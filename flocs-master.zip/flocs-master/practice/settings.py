"""
Practice settings
"""

# ...
