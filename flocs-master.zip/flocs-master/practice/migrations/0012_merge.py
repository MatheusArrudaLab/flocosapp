# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('practice', '0010_auto_20160215_0328'),
        ('practice', '0011_practicesession_task_counter'),
    ]

    operations = [
    ]
