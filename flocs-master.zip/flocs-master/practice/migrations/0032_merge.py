# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('practice', '0031_studentmodel_toolbox'),
        ('practice', '0031_delete_instructionsmodel'),
    ]

    operations = [
    ]
