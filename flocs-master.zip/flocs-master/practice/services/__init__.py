"""Service layer (domain model) of practice app
"""

