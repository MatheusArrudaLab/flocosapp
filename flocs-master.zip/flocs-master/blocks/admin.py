from django.contrib import admin
from .models.block import Block
from .models.toolbox import Toolbox

admin.site.register(Block)
admin.site.register(Toolbox)
