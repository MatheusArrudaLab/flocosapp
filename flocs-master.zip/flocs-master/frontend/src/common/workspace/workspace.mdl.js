/*
 * Workspace component modul
 */
angular.module('flocs.workspace', []);
