/*
 * Module for all flocs filters.
 */
angular.module('flocs.filters', [
]);
