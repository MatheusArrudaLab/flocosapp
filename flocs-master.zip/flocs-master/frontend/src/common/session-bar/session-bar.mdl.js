angular.module('flocs.sessionBar', []);
