/**
 * Localization module
 */
angular.module('flocs.locales', [
]);
