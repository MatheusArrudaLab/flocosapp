/*
 * Module for all flocs services.
 */
angular.module('flocs.services', [
]);
