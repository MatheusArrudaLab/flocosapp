/**
 * Task Environment module
 */
angular.module('flocs.taskEnvironment', [
    'angular-spinkit',

    'flocs.services',
    'flocs.maze',
    'flocs.workspace',
]);
