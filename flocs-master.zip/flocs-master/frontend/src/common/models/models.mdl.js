/*
 * Module for common models used if flocs app
 */
angular.module('flocs.models', [
]);
