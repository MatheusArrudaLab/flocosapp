/*
 * Modul for login formular
 */

angular.module("flocs.user", []);
