/*
 * Profile module
 */
angular.module('flocs.profile', [
]);
