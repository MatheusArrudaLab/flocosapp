/**
 * Header module
 */
angular.module('flocs.header', [
    'flocs.sessionBar',
]);
