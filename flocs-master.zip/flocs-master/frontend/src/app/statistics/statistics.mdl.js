angular.module('flocs.statistics', [
]);
