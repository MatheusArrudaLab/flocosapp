angular.module('flocs.footer', [
]);
