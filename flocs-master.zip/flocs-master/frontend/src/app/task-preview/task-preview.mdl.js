/*
 * Task preview modul
 */
angular.module('flocs.taskPreview', [
    'flocs.services',
    'flocs.taskEnvironment',
]);
