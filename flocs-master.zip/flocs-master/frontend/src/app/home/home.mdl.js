/*
 * Home module
 */
angular.module('flocs.home', [
]);
