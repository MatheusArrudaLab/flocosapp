/**
 * Main home controller
 * @ngInject
 */
angular.module('flocs.home')
.controller('homeCtrl', function($scope) {
});

