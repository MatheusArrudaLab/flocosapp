/*
 * Session overview module
 */
angular.module('flocs.session-overview', [
]);
