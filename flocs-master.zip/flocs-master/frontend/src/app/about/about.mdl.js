angular.module('flocs.about', [
]);
