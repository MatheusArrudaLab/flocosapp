/*
 * Practice modul
 */
angular.module('flocs.practice', [
    'flocs.services',
    'flocs.maze',
    'flocs.workspace'
]);
